package lecture_notes;

public class Example1 {
    public static void main(String[] args) {
        // Primitive data types
        byte by = 123;
        short sh = 12345;
        int n = 1234567890;
        long l = 1234567890;
        float fl = 9.9f;
        double d = 9.9;
        boolean b = true;
        char c = 'a';

        // Reference data types
        String s = "Hello";
        String[] sA = {"Hi", "Bye"};
        int[] nA = {1, 5, 20};
        char[] cA = {'a', 'b'};
        float[] fA = {2.5f, 3.2f};

    }
}
