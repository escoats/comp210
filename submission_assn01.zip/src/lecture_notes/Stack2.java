package lecture_notes;

public class Stack2 {
    public static void main(String[] args) {
        int n = 0;
        char[] c = {'x', 'y', 'z'};
        m1();
    }
    public static void m1() {
        int n1 = 1;
    }
}
