package assn04;
/*
public class deletelater {
    public BST<T> remove(T element) {
        T root = this._element;
        BST<T> current = this;

        if (element.compareTo(root) == 1) {
            // element is larger than root
            if (_left.isEmpty() && _right.isEmpty()) { // leaf
                return new EmptyBST<T>();

            } else if (_left.isEmpty()) {
                current = this._right;
                current.remove(element);

            } else if (_right.isEmpty()) {
                current = this._left;
                current.remove(element);
                //current = this._right;
                //current.remove(element);
            }
        }

        if (element.compareTo(root) == -1) {
            if (_left.isEmpty() && _right.isEmpty()) { // leaf
                return new EmptyBST<T>();

            } else if (_left.isEmpty()) {
                current = this._right;
                current.remove(element);

            } else if (_right.isEmpty()) {
                current = this._left;
                current.remove(element);
                //current = this._left;
                //current.remove(element);
            }
        }

        if (element.compareTo(root) == 0) {
            // element is in the current node
            return new EmptyBST<T>();
        }


        // find parent of element
        // why the hell do we not have a parent pointer mama
        // find the element first!
        // if self.right or self.left have the element, then self is the parent. bruh

        // once element is found:
        // if no children: just delete

        return this;
    }
}
*/